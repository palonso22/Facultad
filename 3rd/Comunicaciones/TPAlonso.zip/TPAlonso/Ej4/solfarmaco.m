function dx = solfarmaco(x,t)
  a=1
  dx=-a*x
 end