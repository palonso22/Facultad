a=1
x0=1
t=0:0.1:10
x=solfarmaco(a,x0,t)
plot(t,x)
title ("Fig 1:Solución analítica para a=1,x0=1")
